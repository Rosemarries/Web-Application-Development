import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h2>โหวตอาหาร</h2>
      </header>
    </div>
  );
}

export default App;
